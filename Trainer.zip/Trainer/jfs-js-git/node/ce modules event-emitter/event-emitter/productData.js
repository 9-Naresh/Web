const products = [
    {
      productId: 1,
      productName: 'ng-book',
      price: 19.95,
      starRating: 3.2,
      image: 'angular.png'
    },
    {
      productId: 2,
      productName: 'Pro Angular',
      price: 32.99,
      starRating: 4.2,
      image: 'proangular.jpg'
    }
  ];

  module.exports = products;
